# Cavity Audio — Speaker Data Status

Generated from `src/data/speakers.json`; counts are not hand-maintained.

Updated 2026-10-18.

The live authoritative dataset contains **657 active catalog records**; the reviewed catalog total is **777** (657 live + 81 archived in scripts/research/removed-unavailable-records.json + 27 archived in scripts/research/removed-owner-round5-records.json, removed at owner request 2026-10-11 + 3 archived in scripts/research/removed-owner-2026-10-12-decisions.json, archived at owner request 2026-10-12 + 8 archived in scripts/research/removed-unavailable-2026-10-12.json, removed at user request 2026-10-12). The archived records were removed from the live dataset at the owner's request on 2026-10-10 (all UNAVAILABLE records, including the duplicate Sonos aliases). They are excluded from speaker selection and from every count in this document. A record is `PARTIALLY_VERIFIED` only when at least one sourced acoustic specification (sensitivity, power, impedance, resonant frequency, voice-coil size, woofer size, or a structured frequency-response limit) is retained. Source-backed structural facts such as driver count or active status alone remain `UNVERIFIED` because they do not supply an acoustic specification for simulation. `UNAVAILABLE` is reserved for unresolved catalog identities and confirmed non-loudspeaker components; those records are retained but excluded from speaker selection.

## Record status
- PARTIALLY_VERIFIED: 657
- UNVERIFIED: 0
- UNAVAILABLE: 0

## Current source-backed fields
- Sensitivity: 305
- Power: 416
- Impedance: 355
- Resonant frequency: 17
- Voice-coil size: 63
- Woofer size: 589
- Frequency-response limits: 561
- Of these, THIRD_PARTY_VERIFIED (retailer or third-party copy of an exact-model spec, not a manufacturer page): 22 field(s) on 11 record(s)

## Response-model policy
- Embedded source-backed response-point datasets: 23 (measurement 0, manufacturer 23, reputable database 0)
- Models derived from published frequency limits: 532
- Generic reference models with missing published bounds: 102
- No synthesized curve is represented as a laboratory measurement.

## Directivity / scatter
- Embedded speaker polar/directivity datasets: 0
- User-imported CSV/JSON directivity: supported, labelled unverified, EXPERIMENTAL (see DIRECTIVITY-IMPORT.md).
- Physical scatter model: not implemented
- Speaker selection alone does not imply speaker-specific room directivity.

## Integrity rule
A missing field is `N/A` rather than guessed. A published bandwidth is not converted into a fabricated frequency-response curve.
